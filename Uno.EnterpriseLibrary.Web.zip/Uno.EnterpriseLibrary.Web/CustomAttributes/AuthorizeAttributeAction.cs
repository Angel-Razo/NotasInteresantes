﻿using EncryptionLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Controllers;
using Uno.EnterpriseLibrary.DataTransferObject;
using Uno.EnterpriseLibrary.Utilities;

namespace Uno.EnterpriseLibrary.Web.CustomAttributes
{
    public class AuthorizeAttributeAction : AuthorizeAttribute
    {
        #region Properties

        private const string ArgumentExceptionMessage = "Falta configurar propiedad AuthorizeAttributeAction.AuthorizeManager";
        private const string AuthorizationHeaderName = "Authorization";
        private static IAuthorizeAttributeManager _authorizeManager;
        private static string _hostAppName;
        private static string _userSystemName;

        public string PermissionGroup { get; set; }
        public string[] Permissions { get; set; }

        #endregion Properties

        #region Public Methods

        public static void Initialize(IAuthorizeAttributeManager authorizeManager
                                      , string hostAppName
                                      , string userSystemName)
        {
            _authorizeManager = authorizeManager;
            _hostAppName = hostAppName;
            _userSystemName = userSystemName;
        }

        #endregion Public Methods

        #region Protected Methods

        protected override bool IsAuthorized(HttpActionContext actionContext)
        {
            return Task.Run(() => AuthorizeAsync(actionContext, PermissionGroup, Permissions)).Result;
        }

        #endregion Protected Methods

        #region Private Methods

        private static async Task<bool> AuthorizeAsync(HttpActionContext httpContext, string permissionGroup
                                                        , string[] permissions)
        {
            bool lAutorized = false;
            KeyValuePair<string, IEnumerable<string>> lAuthorizationHeader;
            string lToken = string.Empty;

            try
            {
                lAuthorizationHeader = httpContext.Request.Headers.FirstOrDefault(h => h.Key.Equals(AuthorizationHeaderName));
                lToken = lAuthorizationHeader.Value == null ? string.Empty: lAuthorizationHeader.Value.FirstOrDefault();

                if (!string.IsNullOrEmpty(lToken))
                {
                    lToken = Encryption.UTF8BytesToString(Encryption.Decrypt(lToken, DateTime.Now.Year.ToString()));
                    lAutorized = validate(lToken, httpContext, permissionGroup, permissions);
                }
            }
            catch (Exception ex)
            {
                LogEvent.SaveError(_hostAppName ?? nameof(AuthorizeAttributeAction), _userSystemName, ex, false);
            }

            return await Task.FromResult(lAutorized);
        }

        private static bool validate(string token, HttpActionContext httpContext,string permissionGroup,  string[] permissions)
        {
            RespuestaDto lResponseValidate;
            TokenDto lTokenValidar = new TokenDto();

            if (_authorizeManager == null)
            {
                throw new ArgumentException(ArgumentExceptionMessage);
            }

            lTokenValidar.Token = token;
            lTokenValidar.GrupoPermisos = permissionGroup;
            lTokenValidar.PermisosAutorizados = permissions;

            lResponseValidate = _authorizeManager.Validar(lTokenValidar);

            if (lResponseValidate.Completado)
            {
                httpContext.Request.Headers.Authorization = new AuthenticationHeaderValue(token, lResponseValidate.Mensaje);
            }

            return lResponseValidate.Completado;
        }

        #endregion Private Methods
    }
}