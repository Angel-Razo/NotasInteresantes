﻿using Uno.EnterpriseLibrary.DataTransferObject;

namespace Uno.EnterpriseLibrary.Web.CustomAttributes
{
    public interface IAuthorizeAttributeManager
    {
        RespuestaDto Validar(TokenDto tokenValidar);
    }
}