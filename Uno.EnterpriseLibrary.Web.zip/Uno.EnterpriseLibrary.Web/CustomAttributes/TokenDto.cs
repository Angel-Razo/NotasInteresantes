﻿namespace Uno.EnterpriseLibrary.Web.CustomAttributes
{
    public class TokenDto
    {
        #region Propiedades

        public string GrupoPermisos { get; set; }
        public string[] PermisosAutorizados { get; set; }
        public string Token { get; set; }
        #endregion Propiedades

        #region Consturctor

        public TokenDto()
        {
            this.Token = string.Empty;
            this.GrupoPermisos = string.Empty;
        }

        #endregion Consturctor
    }
}