﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;
using Uno.EnterpriseLibrary.Utilities;

namespace Uno.EnterpriseLibrary.Web.Utilities
{
    /// <summary>
    /// ICano 201802.
    /// </summary>
    public static class HttpExtensions
    {
        #region Properties

        private static string[] HeadersExclude = { "Accept", "Accept-Encoding", "Connection", "Expect", "Host", "Referer", "User-Agent" };

        #endregion Properties

        #region Public Methods
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="client"></param>
        /// <param name="requestUrl"></param>
        /// <param name="requestContent"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        public static T MakeRequest<T>(this RestClient client, string requestUrl, object requestContent,
                                      HttpRequestMessage request)
        {
            List<KeyValuePair<string, string>> lHeaders = PrepareHeader(request);

            try
            {
                return RestClient.MakeRequest<T>(requestUrl, requestContent,
                                                 request.Method.Method,
                                                 request.Content.Headers.ContentType == null ? string.Empty : request.Content.Headers.ContentType.MediaType,
                                                 lHeaders);
            }
            catch (WebException ex)
            {
                if (ex.Response != null)
                {
                    throw new HttpResponseException(((HttpWebResponse)ex.Response).StatusCode);
                }
                throw;
            }
        }

        /// <summary>
        /// Make Request para cuando no se espera una respuesta.
        /// </summary>
        /// <param name="client"></param>
        /// <param name="requestUrl"></param>
        /// <param name="requestContent"></param>
        /// <param name="request"></param>
        public static void MakeRequest(this RestClient client, string requestUrl, object requestContent,
                                      HttpRequestMessage request)
        {
            List<KeyValuePair<string, string>> lHeaders = PrepareHeader(request);

            try
            {
                RestClient.MakeRequest(requestUrl, requestContent,
                                                 request.Method.Method,
                                                 request.Content.Headers.ContentType == null ? string.Empty : request.Content.Headers.ContentType.MediaType,
                                                 lHeaders);
            }
            catch (WebException ex)
            {
                if (ex.Response != null)
                {
                    throw new HttpResponseException(((HttpWebResponse)ex.Response).StatusCode);
                }
                throw;
            }
        }

        #endregion Public Methods

        #region Private Methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private static List<KeyValuePair<string, string>> PrepareHeader(HttpRequestMessage request)
        {
            List<KeyValuePair<string, string>> lHeaders = new List<KeyValuePair<string, string>>();
            string[] lValues;
            string lValue = string.Empty;

            if (request.Headers != null)
            {
                foreach (var lCab in request.Headers)
                {
                    if (HeadersExclude.Contains(lCab.Key))
                    {
                        continue;
                    }

                    lValues = (string[])lCab.Value;
                    if (lValues.Length > 0)
                    {
                        lValue = lValues[0]; //TODO Validar: Si se tienen que concatenar los valores {,,}
                    }
                    else
                    {
                        lValue = string.Empty;
                    }

                    lHeaders.Add(new KeyValuePair<string, string>(lCab.Key, lValue));
                }
            }

            return lHeaders;
        }
        #endregion
    }
}